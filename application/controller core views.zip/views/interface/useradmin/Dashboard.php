<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php if (!$this->session->agrishop_login_level) { redirect(base_url('login')); } ?>
<?php
$query_produce = "SELECT p.id,
    CASE WHEN p.img_path IS NOT NULL THEN p.img_path ELSE pc.img_path END AS img_path,
    p.name, SUM(mcfp.qty) AS sum_qty
    FROM my_cart_farm_produce mcfp
    LEFT JOIN transaction t ON mcfp.transaction_id = t.id
    LEFT JOIN transaction_cancel tc ON t.id = tc.transaction_id
    LEFT JOIN farm_produce fp ON mcfp.farm_produce_id = fp.id
    LEFT JOIN produce p ON fp.produce_id = p.id
    LEFT JOIN produce_classification pc ON p.produce_classification_id = pc.id
    WHERE tc.id IS NULL GROUP BY p.id, p.name, pc.img_path ";
$fast_produce = $this->db->query($query_produce . "ORDER BY SUM(mcfp.qty) DESC LIMIT 6")->result_array();
$slow_produce = $this->db->query($query_produce . "ORDER BY SUM(mcfp.qty) ASC LIMIT 6")->result_array();
$top_farmers  = json_decode($dashboard['top_farmer']);
$remittance   = json_decode($dashboard['farmer_remittance']);
?>

<style>
.adm-stat { border-radius:16px;padding:18px 20px;border:none;background:#fff;box-shadow:0 2px 12px rgba(0,0,0,.06);transition:transform .18s,box-shadow .18s;position:relative;overflow:hidden; }
.adm-stat:hover { transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.1); }
.adm-stat .stat-icon { width:46px;height:46px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0; }
.adm-stat .stat-val { font-size:26px;font-weight:800;color:#111;line-height:1.1; }
.adm-stat .stat-lbl { font-size:11px;font-weight:600;color:#9ca3af;text-transform:uppercase;letter-spacing:.06em;margin-top:2px; }
.adm-stat .stat-stripe { position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:16px 0 0 16px; }
.adm-card { border-radius:16px;border:none;box-shadow:0 2px 12px rgba(0,0,0,.06);overflow:hidden; }
.adm-card-header { padding:12px 18px;font-weight:700;font-size:13px;display:flex;align-items:center;gap:8px;border-bottom:1px solid #f3f4f6;background:#fff; }
.ldr-row { display:flex;align-items:center;gap:12px;padding:10px 16px;border-bottom:1px solid #f9fafb;transition:background .15s; }
.ldr-row:last-child { border-bottom:none; }
.ldr-row:hover { background:#f9fafb; }
.ldr-rank { width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:800;flex-shrink:0; }
.rank-1{background:#fef9c3;color:#92400e;} .rank-2{background:#f3f4f6;color:#374151;} .rank-3{background:#fef3e2;color:#92400e;} .rank-n{background:#f0fdf4;color:#166534;}
.produce-pill { display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:10px;background:#f9fafb;border:1px solid #f3f4f6;transition:background .15s;margin-bottom:6px; }
.produce-pill:hover { background:#f0fdf4; }
.produce-pill img { width:36px;height:36px;border-radius:8px;object-fit:cover; }
.produce-pill .pname { font-size:12px;font-weight:600;color:#111; }
.produce-pill .pqty  { font-size:11px;color:#6b7280;margin-top:1px; }
@keyframes pulse-badge { 0%,100%{box-shadow:0 0 0 0 rgba(220,53,69,.4);} 50%{box-shadow:0 0 0 8px rgba(220,53,69,0);} }
.badge-pulse { animation:pulse-badge 2s infinite; }
</style>

<!-- Page Header -->
<section class="content-header">
<div class="container-fluid">
<div class="row mt-2 mb-n1">
<div class="col-sm-7">
<h5 class="m-0 font-weight-bold"><i class="fa fa-chart-pie text-primary mr-1"></i> Admin Dashboard</h5>
<small class="text-muted"><?= date('l, F j, Y') ?></small>
</div>
<div class="col-sm-5 text-right">
<span class="badge badge-light border" style="font-size:11px;padding:6px 12px;"><i class="fa fa-circle text-success mr-1" style="font-size:8px;"></i> Live Data</span>
</div>
</div>
</div>
</section>

<section class="content">
<div class="container-fluid">

<!-- PENDING APPROVALS -->
<?php if (($dashboard['pending_farmers'] + $dashboard['pending_suppliers']) > 0): ?>
<div class="alert d-flex align-items-center mb-3" style="border-radius:14px;background:linear-gradient(135deg,#fff3cd,#ffeeba);border:none;box-shadow:0 2px 12px rgba(255,193,7,.2);">
<div class="badge-pulse rounded-circle d-flex align-items-center justify-content-center mr-3" style="width:40px;height:40px;background:#dc3545;flex-shrink:0;"><i class="fa fa-user-clock text-white"></i></div>
<div class="flex-grow-1">
<strong>Pending Approvals</strong>
<div style="font-size:13px;margin-top:2px;">
<?php if ($dashboard['pending_farmers'] > 0): ?><span class="badge badge-danger mr-1"><?= $dashboard['pending_farmers'] ?> Farmer<?= $dashboard['pending_farmers'] > 1 ? 's' : '' ?></span><?php endif; ?>
<?php if ($dashboard['pending_suppliers'] > 0): ?><span class="badge badge-warning"><?= $dashboard['pending_suppliers'] ?> Supplier<?= $dashboard['pending_suppliers'] > 1 ? 's' : '' ?></span><?php endif; ?>
waiting for review.
</div>
</div>
<a href="<?= base_url('useradmin/Users') ?>" class="btn btn-sm btn-dark font-weight-bold rounded-pill px-3">Review <i class="fa fa-arrow-right ml-1"></i></a>
</div>
<?php endif; ?>

<!-- STAT CARDS -->
<?php
$cards = [
['label'=>'Total Users','val'=>$dashboard['user'],'icon'=>'fa-users','color'=>'#3b82f6','bg'=>'#eff6ff'],
['label'=>'Farmers','val'=>$dashboard['farmer'],'icon'=>'fa-tractor','color'=>'#22c55e','bg'=>'#f0fdf4'],
['label'=>'Suppliers','val'=>$dashboard['total_suppliers'],'icon'=>'fa-store','color'=>'#f97316','bg'=>'#fff7ed'],
['label'=>'Active Subs','val'=>$dashboard['subscription'],'icon'=>'fa-crown','color'=>'#eab308','bg'=>'#fefce8'],
['label'=>'Completed Orders','val'=>$dashboard['completed_orders'],'icon'=>'fa-check-circle','color'=>'#14b8a6','bg'=>'#f0fdfa'],
['label'=>'Subscription Revenue','val'=>'&#8369;'.$dashboard['revenue'],'icon'=>'fa-money-bill-wave','color'=>'#ef4444','bg'=>'#fef2f2'],
['label'=>'Total Farms','val'=>$dashboard['total_farms'],'icon'=>'fa-house-chimney','color'=>'#8b5cf6','bg'=>'#f5f3ff'],
['label'=>'Produce Types','val'=>$dashboard['total_produce'],'icon'=>'fa-seedling','color'=>'#06b6d4','bg'=>'#ecfeff'],
];
?>
<div class="row mb-4">
<?php foreach ($cards as $c): ?>
<div class="col-6 col-md-3 mb-3">
<div class="adm-stat">
<div class="stat-stripe" style="background:<?= $c['color'] ?>;"></div>
<div class="d-flex justify-content-between align-items-start">
<div><div class="stat-lbl"><?= $c['label'] ?></div><div class="stat-val mt-1"><?= $c['val'] ?></div></div>
<div class="stat-icon" style="background:<?= $c['bg'] ?>;color:<?= $c['color'] ?>;"><i class="fa <?= $c['icon'] ?>"></i></div>
</div>
</div>
</div>
<?php endforeach; ?>
</div>

<!-- CHARTS -->
<div class="row mb-4">
<div class="col-lg-8 mb-3">
<div class="adm-card card">
<div class="adm-card-header"><i class="fa fa-chart-area text-success"></i> Revenue Trend — <?= date('Y') ?> <span class="ml-auto badge badge-light border" style="font-size:10px;">Subscription</span></div>
<div class="card-body p-3"><canvas id="revenueTrend" height="90"></canvas></div>
</div>
</div>
<div class="col-lg-4 mb-3">
<div class="adm-card card h-100">
<div class="adm-card-header"><i class="fa fa-chart-bar text-primary"></i> Orders by Month</div>
<div class="card-body p-3"><canvas id="ordersAnalytics" height="160"></canvas></div>
</div>
</div>
</div>

<!-- TOP FARMERS + BILLING -->
<div class="row mb-4">
<div class="col-lg-6 mb-3">
<div class="adm-card card">
<div class="adm-card-header"><i class="fa fa-trophy text-warning"></i> Top Farmers by Sales</div>
<div class="card-body p-0">
<?php if (empty($top_farmers)): ?>
<div class="text-center text-muted py-4" style="font-size:13px;"><i class="fa fa-tractor fa-2x mb-2 d-block"></i>No data yet</div>
<?php else: ?>
<?php $medals=['🥇','🥈','🥉'];$i=0; foreach ($top_farmers as $f): $i++; ?>
<div class="ldr-row">
<div class="ldr-rank <?= $i===1?'rank-1':($i===2?'rank-2':($i===3?'rank-3':'rank-n')) ?>"><?= $medals[$i-1] ?? $i ?></div>
<div class="flex-grow-1"><div style="font-size:13px;font-weight:600;color:#111;"><?= htmlspecialchars($f->farmer ?? '—') ?></div></div>
<div style="font-size:13px;font-weight:700;color:#22c55e;">&#8369;<?= number_format($f->revenue ?? 0, 2) ?></div>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>
</div>
</div>
<div class="col-lg-6 mb-3">
<div class="adm-card card">
<div class="adm-card-header"><i class="fa fa-file-invoice text-warning"></i> Farmer Subscription Billing</div>
<div class="card-body p-0">
<?php if (empty($remittance)): ?>
<div class="text-center text-muted py-4" style="font-size:13px;"><i class="fa fa-wallet fa-2x mb-2 d-block"></i>No billing records</div>
<?php else: ?>
<?php foreach ($remittance as $r): ?>
<div class="ldr-row">
<div style="flex:1;"><div style="font-size:13px;font-weight:600;color:#111;"><?= htmlspecialchars($r->farmer ?? '—') ?></div></div>
<div style="font-size:13px;font-weight:700;color:#111;margin-right:10px;">&#8369;<?= number_format($r->amount ?? 0, 2) ?></div>
<span class="badge <?= $r->status=='t'?'badge-success':'badge-warning' ?>" style="font-size:10px;padding:4px 8px;"><?= $r->status=='t'?'✓ PAID':'⏳ PENDING' ?></span>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>
</div>
</div>
</div>

<!-- FAST + SLOW PRODUCE -->
<div class="row mb-3">
<div class="col-lg-6 mb-3">
<div class="adm-card card">
<div class="adm-card-header"><i class="fa fa-fire text-danger"></i> 🔥 Fast Moving Produce <span class="ml-auto text-muted" style="font-size:11px;font-weight:400;">Top 6</span></div>
<div class="card-body p-3">
<?php if (empty($fast_produce)): ?><div class="text-center text-muted py-3" style="font-size:13px;">No data yet</div>
<?php else: ?><div class="row">
<?php foreach ($fast_produce as $p): ?>
<div class="col-6">
<div class="produce-pill">
<img src="<?= base_url($p['img_path']??'dist/img/media/icons/1x1.png') ?>" onerror="this.src='<?= base_url('dist/img/media/icons/1x1.png') ?>'">
<div><div class="pname"><?= htmlspecialchars($p['name']??'—') ?></div><div class="pqty"><span class="badge badge-success" style="font-size:10px;"><?= $p['sum_qty'] ?> sold</span></div></div>
</div>
</div>
<?php endforeach; ?></div><?php endif; ?>
</div>
</div>
</div>
<div class="col-lg-6 mb-3">
<div class="adm-card card">
<div class="adm-card-header"><i class="fa fa-icicles text-info"></i> 🧊 Slow Moving Produce <span class="ml-auto text-muted" style="font-size:11px;font-weight:400;">Bottom 6</span></div>
<div class="card-body p-3">
<?php if (empty($slow_produce)): ?><div class="text-center text-muted py-3" style="font-size:13px;">No data yet</div>
<?php else: ?><div class="row">
<?php foreach ($slow_produce as $p): ?>
<div class="col-6">
<div class="produce-pill">
<img src="<?= base_url($p['img_path']??'dist/img/media/icons/1x1.png') ?>" onerror="this.src='<?= base_url('dist/img/media/icons/1x1.png') ?>'">
<div><div class="pname"><?= htmlspecialchars($p['name']??'—') ?></div><div class="pqty"><span class="badge badge-secondary" style="font-size:10px;"><?= $p['sum_qty'] ?> sold</span></div></div>
</div>
</div>
<?php endforeach; ?></div><?php endif; ?>
</div>
</div>
</div>
</div>

</div></section>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const revenueData    = <?= $dashboard['revnue_trendGraph'] ?>;
const orderAnalytics = <?= $dashboard['orderAnalyticsGraph'] ?>;
Chart.defaults.font.size = 11;
new Chart(document.getElementById('revenueTrend'),{type:'line',data:{labels:revenueData.map(d=>d.month),datasets:[{label:'Revenue (₱)',data:revenueData.map(d=>d.revenue),borderColor:'#22c55e',backgroundColor:function(ctx){var g=ctx.chart.ctx.createLinearGradient(0,0,0,220);g.addColorStop(0,'rgba(34,197,94,.22)');g.addColorStop(1,'rgba(34,197,94,0)');return g;},borderWidth:2.5,tension:.42,fill:true,pointBackgroundColor:'#22c55e',pointRadius:4,pointHoverRadius:6}]},options:{responsive:true,plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>' ₱'+parseFloat(ctx.parsed.y).toLocaleString()}}},scales:{x:{grid:{display:false},ticks:{color:'#9ca3af'}},y:{beginAtZero:true,grid:{color:'#f3f4f6'},ticks:{color:'#9ca3af',callback:v=>'₱'+v.toLocaleString()}}}}});
new Chart(document.getElementById('ordersAnalytics'),{type:'bar',data:{labels:orderAnalytics.map(d=>d.month),datasets:[{label:'Orders',data:orderAnalytics.map(d=>d.orders),backgroundColor:'rgba(59,130,246,.75)',borderRadius:6,borderSkipped:false}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{color:'#9ca3af'}},y:{beginAtZero:true,grid:{color:'#f3f4f6'},ticks:{color:'#9ca3af'}}}}});
</script>
